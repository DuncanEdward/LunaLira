# Luna Lira 🌕📈

A financial astrology app powered by Streamlit.

## Deploy to Render

1. Push this repo to GitHub
2. Visit https://render.com and select "New Web Service"
3. Connect your GitHub repo
4. Render auto-detects `render.yaml` and builds the app